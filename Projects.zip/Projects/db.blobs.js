// db.blobs.js
const { getStore } = require('@netlify/blobs');
const store = getStore('biolink-db');

async function readDB() {
  return (await store.get('db', { type: 'json' })) || defaultDB();
}
async function writeDB(data) {
  await store.setJSON('db', data);
}
module.exports = { readDB, writeDB };
