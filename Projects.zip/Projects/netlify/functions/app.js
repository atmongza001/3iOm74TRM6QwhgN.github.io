const serverless = require('serverless-http');
const app = require('../../server'); // ชี้มาที่ไฟล์ที่ export app
exports.handler = serverless(app);
